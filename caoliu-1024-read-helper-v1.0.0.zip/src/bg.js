// (async function () {
//     let nn = await chrome.tabs.query({'active': true}); 
//     console.log(nn);
    
// })()
